package com.ramaa.finalprojectpokemontcg.data.remote.responses


data class VersionGroup(
    val name: String,
    val url: String
)