package com.ramaa.finalprojectpokemontcg.data.remote.responses


data class Species(
    val name: String,
    val url: String
)