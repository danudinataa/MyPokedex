package com.ramaa.finalprojectpokemontcg.data.remote.responses


data class MoveX(
    val name: String,
    val url: String
)