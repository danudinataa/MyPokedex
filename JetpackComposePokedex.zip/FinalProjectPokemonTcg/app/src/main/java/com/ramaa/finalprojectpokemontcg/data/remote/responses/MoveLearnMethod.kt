package com.ramaa.finalprojectpokemontcg.data.remote.responses


data class MoveLearnMethod(
    val name: String,
    val url: String
)