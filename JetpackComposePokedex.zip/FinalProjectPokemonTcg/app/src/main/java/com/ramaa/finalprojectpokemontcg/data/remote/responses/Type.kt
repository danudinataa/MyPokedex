package com.ramaa.finalprojectpokemontcg.data.remote.responses


data class Type(
    val slot: Int,
    val type: TypeX
)