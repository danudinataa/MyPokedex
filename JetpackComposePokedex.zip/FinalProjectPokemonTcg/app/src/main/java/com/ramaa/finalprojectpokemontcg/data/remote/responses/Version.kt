package com.ramaa.finalprojectpokemontcg.data.remote.responses


data class Version(
    val name: String,
    val url: String
)