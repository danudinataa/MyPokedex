package com.ramaa.finalprojectpokemontcg.data.remote.responses


data class Form(
    val name: String,
    val url: String
)