package com.ramaa.finalprojectpokemontcg.data.remote.responses


data class StatX(
    val name: String,
    val url: String
)